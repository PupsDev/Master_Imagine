
#include <stdio.h>
#include "image_ppm.h"

int main(int argc, char* argv[])
{
  char cNomImgLue[250], cNomImgEcrite[250];
  int nH, nW, nTaille, S;
  unsigned int occurence [256]={0};
  
  if (argc != 3) 
     {
       printf("Usage: ImageIn.pgm ImageOut.pgm Seuil \n"); 
       exit (1) ;
     }
   sscanf (argv[1],"%s",cNomImgLue) ;
   sscanf (argv[2],"%s",cNomImgEcrite);

   OCTET *ImgIn, *ImgOut;
   
   lire_nb_lignes_colonnes_image_pgm(cNomImgLue, &nH, &nW);
   nTaille = nH * nW;
    printf("%d %d\n", nH , nW); 
  
   allocation_tableau(ImgIn, OCTET, nTaille);
   lire_image_pgm(cNomImgLue, ImgIn, nH * nW);
   allocation_tableau(ImgOut, OCTET, nTaille);
	
 for (int i=0; i < nTaille; i++){
       occurence[ImgIn[i]]++;  
     }
    
    for (int i=0; i < 256; i++)
     	printf("%f\n", (float)occurence[i]/(float)nTaille);


    FILE *f_image;

   if( (f_image = fopen("histo2.dat", "wb")) == NULL)
      {

	 exit(EXIT_FAILURE);
      }
   else
      {
	  for(int i = 0 ; i < 256 ; i ++)                        
	 		fprintf(f_image,"%d %f\n", i, (float)occurence[i]/(float)nTaille) ;

	 fclose(f_image);
      }


   if( (f_image = fopen("ddp2.dat", "wb")) == NULL)
      {

	 exit(EXIT_FAILURE);
      }
   else
      {
      	float sum = 0.;
	  for(int i = 0 ; i < 256 ; i ++)
	  {
	  	sum += (float)((float)occurence[i]/(float)nTaille);
	  	fprintf(f_image,"%d %f\n", i, sum) ;
	  }                   
	 		

	 fclose(f_image);
      }
      float moyenne=0., variance=0. , ecart;
 for (int i=0; i < nTaille; i++){
       moyenne += (float)ImgIn[i];  
     }
    moyenne/=(float)nTaille;
     for (int i=0; i < nTaille; i++){
       variance += ((float)ImgIn[i]-moyenne)*((float)ImgIn[i]-moyenne);  
     }
     variance/=(float)nTaille;

     ecart = sqrt(variance);
     printf("moyenne %f variance %f ecart %f\n", moyenne, variance, ecart);


   if( (f_image = fopen("gauss2.dat", "wb")) == NULL)
      {
    exit(EXIT_FAILURE);
      }
   else
      {
     for(int i = 0 ; i < 256 ; i ++)
     {
       float z = (float) 1./(ecart*sqrt(2.*M_PI))*exp(-((i-moyenne)*(i-moyenne)) /((float)2.*ecart*ecart));
      fprintf(f_image,"%d %f\n", i, z) ;
     }                      
      
    fclose(f_image);
      }

   ecrire_image_pgm(cNomImgEcrite, ImgOut,  nH, nW);
   free(ImgIn); free(ImgOut);

   return 1;
}
