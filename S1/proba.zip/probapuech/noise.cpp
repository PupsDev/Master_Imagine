// blur.cpp : Floute une image en niveau de gris

#include <stdio.h>
#include "image_ppm.h"

int main(int argc, char* argv[])
{
  char cNomImgLue[250], cNomImgEcrite[250];
  int nH, nW, nTaille;
  int som;
  if (argc != 3) 
     {
       printf("Usage: ImageIn.pgm ImageOut.pgm \n"); 
       exit (1) ;
     }
   
   sscanf (argv[1],"%s",cNomImgLue) ;
   sscanf (argv[2],"%s",cNomImgEcrite);
     unsigned int occurence [256]={0};

   OCTET *ImgIn, *ImgOut;
   
   lire_nb_lignes_colonnes_image_pgm(cNomImgLue, &nH, &nW);
   nTaille = nH * nW;
  
   allocation_tableau(ImgIn, OCTET, nTaille);
   lire_image_pgm(cNomImgLue, ImgIn, nH * nW);
   allocation_tableau(ImgOut, OCTET, nTaille);
	 for (int i=0; i < nTaille; i++){
       occurence[ImgIn[i]]++;  
     }
    
    /*for (int i=0; i < 256; i++)
      printf("%f\n", (float)occurence[i]/(float)nTaille);*/

   for (int i=0; i < nTaille; i++)
    ImgOut[i]= ImgIn[i];

 for (int i=1; i < nH-1; i++)
   for (int j=1; j < nW-1; j++)
     {
		som=
		 ImgIn[(i-1)*nW+j-1]+ImgIn[(i-1)*nW+j]+ImgIn[(i-1)*nW+j+1]
		+ImgIn[i*nW+j-1]+ImgIn[i*nW+j]+ImgIn[i*nW+j+1]
		+ImgIn[(i+1)*nW+j-1]+ImgIn[(i+1)*nW+j]+ImgIn[(i+1)*nW+j+1];
		
       ImgOut[i*nW+j]=som/9;
     }
  OCTET pixel; 
  for (int i=1; i < nH-1; i++)
    for (int j=1; j < nW-1; j++)
    {
      pixel= ImgOut[i*nW+j]-ImgIn[i*nW+j];
      if(pixel<-128)pixel=128;
      if(pixel>127)pixel=127;
      pixel+=128;
      ImgOut[i*nW+j] = pixel;
    }

    float moyenne=0., variance=0. , ecart;
    for (int i=0; i < nTaille; i++){
       moyenne += (float)ImgIn[i];  
     }
    moyenne/=(float)nTaille;
     for (int i=0; i < nTaille; i++){
       variance += ((float)ImgIn[i]-moyenne)*((float)ImgIn[i]-moyenne);  
     }
     variance/=(float)nTaille;

     ecart = sqrt(variance);
     printf("moyenne %f variance %f ecart %f\n", moyenne, variance, ecart);

     FILE *f_image;

    if( (f_image = fopen("GaussianNoice.dat", "wb")) == NULL)
      {
    exit(EXIT_FAILURE);
      }
   else
      {
       for(int i = 0 ; i < 256 ; i ++)
       {
         float z = (float) 1./(ecart*sqrt(2.*M_PI))*exp(-((i-moyenne)*(i-moyenne)) /((float)2.*ecart*ecart));
        fprintf(f_image,"%d %f\n", i, z) ;
       }                      
    
   
    fclose(f_image);
      }
       int b =(int)ecart/sqrt(2);
       printf("b = %d",b);
        if( (f_image = fopen("LaplacianNoice.dat", "wb")) == NULL)
      {
    exit(EXIT_FAILURE);
      }
   else
      {
        float z;
       for(int i = 0 ; i < 256 ; i ++)
       {

        z = (float) (exp(-abs(moyenne-i)/b))/(2*b);

 
        fprintf(f_image,"%d %f\n", i, z) ;
       }                      
      
    fclose(f_image);
      }

    if( (f_image = fopen("histoNoice.dat", "wb")) == NULL)
      {

   exit(EXIT_FAILURE);
      }
   else
      {
        float sum = 0.;
    for(int i = 0 ; i < 256 ; i ++)
    {
      sum = (float)((float)occurence[i]/(float)nTaille);
      fprintf(f_image,"%d %f\n", i, sum) ;
    }  
  }

  int cadranNH, cadranNW;
  cadranNH = nH/4;
  cadranNW = nW/4;

  float moyenne2[4]={0.}, variance2[4]={0.} , ecart2[4]={0.};

  for(int i = 0 ; i < 2;i++)
  {
    for(int j =0; j< 2;j++)
    {
      for(int k = 0 ; k < cadranNH;k++)
      {
        for(int l =0; l<cadranNW;l++)
        {
          moyenne2[2*i+j] += (float)ImgIn[i*cadranNH+ j*cadranNW+ k*cadranNH + cadranNW];
        }
      }

    }
  }

  float tailleCadran = cadranNH*cadranNW;
  for(int i =0;i<4;i++)
  {
    moyenne2[i]/=tailleCadran;
  }
  for(int i = 0 ; i < 2;i++)
  {
    for(int j =0; j< 2;j++)
    {
      for(int k = 0 ; k < cadranNH;k++)
      {
        for(int l =0; l<cadranNW;l++)
        {
          variance2[2*i+j] += ((float)ImgIn[i*cadranNH+ j*cadranNW+ k*cadranNH + cadranNW]-moyenne2[2*i+j])*((float)ImgIn[i*cadranNH+ j*cadranNW+ k*cadranNH + cadranNW]-moyenne2[2*i+j]);
        }
      }

    }
  }
  for(int i =0;i<4;i++)
  {
    variance2[i]/=tailleCadran;
  }

  

   ecrire_image_pgm(cNomImgEcrite, ImgOut,  nH, nW);
   free(ImgIn);free(ImgOut);
   return 1;
}
