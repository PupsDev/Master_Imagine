
#include <stdio.h>
#include <math.h>
#include "image_ppm.h"

int main(int argc, char* argv[])
{
  char cNomImgLue[250], cNomImgEcrite[250];
  int nH, nW, nTaille, S;
  unsigned int occurence [256]={0};
  
  if (argc != 2) 
     {
       printf("Usage: ImageIn.pgm ImageOut.pgm Seuil \n"); 
       exit (1) ;
     }
   sscanf (argv[1],"%s",cNomImgLue) ;

   OCTET *ImgIn;
   
   lire_nb_lignes_colonnes_image_pgm(cNomImgLue, &nH, &nW);
   nTaille = nH * nW;
    printf("%d %d\n", nH , nW); 
  
   allocation_tableau(ImgIn, OCTET, nTaille);
   lire_image_pgm(cNomImgLue, ImgIn, nH * nW);
	
float moyenne=0., variance=0. , ecart;
 for (int i=0; i < nTaille; i++){
       moyenne += (float)ImgIn[i];  
     }
    moyenne/=(float)nTaille;
     for (int i=0; i < nTaille; i++){
       variance += ((float)ImgIn[i]-moyenne)*((float)ImgIn[i]-moyenne);  
     }
     variance/=(float)nTaille;

     ecart = sqrt(variance);
     printf("moyenne %f variance %f ecart %f\n", moyenne, variance, ecart);

    FILE *f_image;
   if( (f_image = fopen("gauss.dat", "wb")) == NULL)
      {
	 exit(EXIT_FAILURE);
      }
   else
      {
	  for(int i = 0 ; i < 256 ; i ++)
     {
       float z = (float) 2/(ecart*sqrt(2.*3.14159265))*exp(-((i-moyenne)*(i-moyenne)) /((float)2.*ecart*ecart));
      fprintf(f_image,"%d %f\n", i, nTaille*z) ;
     }                      
	 	
	 fclose(f_image);
      }
   free(ImgIn); 

   return 1;
}
