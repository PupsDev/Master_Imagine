# HAI702I_tp
Compilation 
------------
make


Execution 
------------
./tp

Il y a les 3 algos de disponible: On peut appuyer sur 'G' pour graham, 'J' pour jarvis et 'D' pour demi-plan, à chaque fois un nouveau nuage de points aléatoires sera calculé et son envelopppe convexe.