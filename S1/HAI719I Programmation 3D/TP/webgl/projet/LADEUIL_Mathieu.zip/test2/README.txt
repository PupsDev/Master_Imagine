J'ai essayé de comprendre et de refaire la windmap, au final c'est très inspiré du code original mais cela m'a permit de mieux comprendre le webgl.

1/ python3 -m http.server
2/ http://localhost:8000/