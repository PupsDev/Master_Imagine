Ex 1-2

P2P1 le vecteur généré par P2-P1
P3  = Proj(P2,P2P1) = P2P1*(dot(P4,P2P1)/dot(P2P1,P2P1))
Même chose pour P7

AN:
P3 = (0.068,0.1134)
P7 = (0.1121,0.1681)

Ex 3

projection "orthographique" et transformation de modélisation

Ex 4

b : 5*rotation(a,60°)
c : b et mirroir(a, X) (par l'axe X)
d : b et  5*rotation(mirroir(a, X),60°)

Ex 5:
a scale(0.5)
b sheering(alpha°)

Ex 6-7 cf code 
 