Exercice 1 cube texturé avec l'image
Excercice 2 génération procédural d'un papier peint de polygones, on peut varier le nombre de sommet
